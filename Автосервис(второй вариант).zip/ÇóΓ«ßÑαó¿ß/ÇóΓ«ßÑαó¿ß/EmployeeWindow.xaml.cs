﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace Автосервис
{
    public partial class EmployeeWindow : Window
    {
        private readonly int _employeeId;
        private readonly DatabaseHelper _dbHelper;
        public EmployeeWindow(int employeeId)
        {
            InitializeComponent();
            _employeeId = employeeId;
            _dbHelper = new DatabaseHelper();
            LoadEmployeeData();
            LoadCurrentOrders();
        }
        private void LoadEmployeeData()
        {
            try
            {
                string query = "SELECT Фамилия, Имя, Отчество, Должность FROM Сотрудники WHERE ID_сотрудника = @EmployeeId";
                SqlParameter[] parameters = {
                    new SqlParameter("@EmployeeId", SqlDbType.Int) { Value = _employeeId }
                };

                DataTable result = _dbHelper.ExecuteQuery(query, parameters);

                if (result.Rows.Count > 0)
                {
                    DataRow row = result.Rows[0];
                    string lastName = row["Фамилия"].ToString();
                    string firstName = row["Имя"].ToString();
                    string middleName = row["Отчество"].ToString();
                    string position = row["Должность"].ToString();

                    this.Title = $"Панель сотрудника - {lastName} {firstName} {middleName} ({position})";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных сотрудника: {ex.Message}");
            }
        }

        private void LoadCurrentOrders()
        {
            try
            {
                string query = @"SELECT 
                                z.ID_заказа,
                                z.Дата_создания,
                                z.Статус,
                                z.Общая_стоимость,
                                CONCAT(к.Фамилия, ' ', к.Имя) AS Клиент,
                                CONCAT(а.Марка, ' ', а.Модель) AS Автомобиль
                              FROM Заказы z
                              JOIN Автомобили а ON z.ID_автомобиля = а.ID_автомобиля
                              JOIN Клиенты к ON а.ID_клиента = к.ID_клиента
                              WHERE z.ID_сотрудника = @EmployeeId
                              ORDER BY z.Дата_создания DESC";

                SqlParameter[] parameters = {
                    new SqlParameter("@EmployeeId", SqlDbType.Int) { Value = _employeeId }
                };

                DataTable orders = _dbHelper.ExecuteQuery(query, parameters);
                dgOrders.ItemsSource = orders.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}");
            }
        }

        private void BtnUpdateStatus_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrders.SelectedItem == null)
            {
                MessageBox.Show("Выберите заказ для обновления статуса");
                return;
            }

            if (cmbStatus.SelectedItem == null)
            {
                MessageBox.Show("Выберите новый статус");
                return;
            }

            DataRowView row = (DataRowView)dgOrders.SelectedItem;
            int orderId = Convert.ToInt32(row["ID_заказа"]);
            string newStatus = ((ComboBoxItem)cmbStatus.SelectedItem).Content.ToString();

            try
            {
                string query = "UPDATE Заказы SET Статус = @Status WHERE ID_заказа = @OrderId";
                SqlParameter[] parameters = {
                    new SqlParameter("@Status", SqlDbType.NVarChar) { Value = newStatus },
                    new SqlParameter("@OrderId", SqlDbType.Int) { Value = orderId }
                };

                int rowsAffected = _dbHelper.ExecuteNonQuery(query, parameters);

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Статус заказа успешно обновлен");
                    LoadCurrentOrders();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления статуса: {ex.Message}");
            }

        }
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            // Здесь вы можете добавить логику выхода, например, закрытие окна или возврат на экран входа
            this.Close(); // Закрывает текущее окно
        }
    }
}
