﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace Автосервис
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly DatabaseHelper _dbHelper;
        public MainWindow()
        {
            InitializeComponent();
            _dbHelper = new DatabaseHelper();

            // Проверка подключения к базе данных
            if (!_dbHelper.TestConnection())
            {
                MessageBox.Show("Ошибка подключения к базе данных", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }
        }
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                lblError.Text = "Введите логин и пароль";
                lblError.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                // Проверка учетных данных
                string query = @"SELECT Роль, ID_сотрудника, ID_клиента 
                                FROM Учетные_данные 
                                WHERE Логин = @Login AND Пароль = @Password";

                SqlParameter[] parameters = {
                    new SqlParameter("@Login", SqlDbType.NVarChar) { Value = login },
                    new SqlParameter("@Password", SqlDbType.NVarChar) { Value = password }
                };

                DataTable result = _dbHelper.ExecuteQuery(query, parameters);

                if (result.Rows.Count > 0)
                {
                    DataRow row = result.Rows[0];
                    string role = row["Роль"].ToString();

                    if (role == "Сотрудник")
                    {
                        int employeeId = Convert.ToInt32(row["ID_сотрудника"]);
                        EmployeeWindow employeeWindow = new EmployeeWindow(employeeId);
                        employeeWindow.Show();
                        this.Hide();
                    }
                    else if (role == "Клиент")
                    {
                        int clientId = Convert.ToInt32(row["ID_клиента"]);
                        ClientWindow clientWindow = new ClientWindow(clientId);
                        clientWindow.Show();
                        this.Hide();
                    }
                }
                else
                {
                    lblError.Text = "Неверный логин или пароль";
                    lblError.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
