﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace Автосервис
{
    public partial class ClientWindow : Window
    {
        private int clientId;
        private string connectionString = "Server=.;Database=Автосервис;Integrated Security=True;";
        public ClientWindow(int clientId)
        {
            InitializeComponent();
            this.clientId = clientId;
            LoadClientData();
        }
        private void LoadClientData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Загрузка заказов клиента
                    string ordersQuery = @"SELECT * FROM Заказы 
                                          WHERE ID_автомобиля IN 
                                          (SELECT ID_автомобиля FROM Автомобили WHERE ID_клиента = @ClientId)";

                    SqlDataAdapter ordersAdapter = new SqlDataAdapter(ordersQuery, connection);
                    ordersAdapter.SelectCommand.Parameters.AddWithValue("@ClientId", clientId);

                    DataTable ordersTable = new DataTable();
                    ordersAdapter.Fill(ordersTable);
                    dgOrders.ItemsSource = ordersTable.DefaultView;

                    // Загрузка запчастей клиента
                    string partsQuery = @"SELECT z.ID_заказа, з.Наименование, sz.Количество, 
                                        sz.Цена_на_момент_продажи, 
                                        (sz.Количество * sz.Цена_на_момент_продажи) AS Сумма
                                        FROM Состав_заказа_запчасти sz
                                        JOIN Запчасти з ON sz.ID_запчасти = з.ID_запчасти
                                        JOIN Заказы z ON sz.ID_заказа = z.ID_заказа
                                        WHERE z.ID_автомобиля IN 
                                        (SELECT ID_автомобиля FROM Автомобили WHERE ID_клиента = @ClientId)";

                    SqlDataAdapter partsAdapter = new SqlDataAdapter(partsQuery, connection);
                    partsAdapter.SelectCommand.Parameters.AddWithValue("@ClientId", clientId);

                    DataTable partsTable = new DataTable();
                    partsAdapter.Fill(partsTable);
                    dgParts.ItemsSource = partsTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
