﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace Автосервис
{
    public partial class EmployeeWindow : Window
    {
        private int employeeId;
        private string connectionString = "Server=.;Database=Автосервис;Integrated Security=True;";
        public EmployeeWindow(int employeeId)
        {
            InitializeComponent();
            this.employeeId = employeeId;
            LoadEmployeeData();
            LoadCurrentOrders();
        }
        private void LoadEmployeeData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Получаем информацию о сотруднике
                    string employeeQuery = "SELECT Фамилия, Имя, Отчество, Должность FROM Сотрудники WHERE ID_сотрудника = @EmployeeId";
                    SqlCommand employeeCommand = new SqlCommand(employeeQuery, connection);
                    employeeCommand.Parameters.AddWithValue("@EmployeeId", employeeId);

                    using (SqlDataReader reader = employeeCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string lastName = reader["Фамилия"].ToString();
                            string firstName = reader["Имя"].ToString();
                            string middleName = reader["Отчество"].ToString();
                            string position = reader["Должность"].ToString();

                            this.Title = $"Панель сотрудника - {lastName} {firstName} {middleName} ({position})";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных сотрудника: {ex.Message}");
            }
        }

        private void LoadCurrentOrders()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Загрузка текущих заказов, назначенных сотруднику
                    string ordersQuery = @"SELECT 
                                            z.ID_заказа,
                                            z.Дата_создания,
                                            z.Статус,
                                            z.Общая_стоимость,
                                            CONCAT(к.Фамилия, ' ', к.Имя) AS Клиент,
                                            CONCAT(а.Марка, ' ', а.Модель) AS Автомобиль
                                          FROM Заказы z
                                          JOIN Автомобили а ON z.ID_автомобиля = а.ID_автомобиля
                                          JOIN Клиенты к ON а.ID_клиента = к.ID_клиента
                                          WHERE z.ID_сотрудника = @EmployeeId
                                          ORDER BY z.Дата_создания DESC";

                    SqlDataAdapter ordersAdapter = new SqlDataAdapter(ordersQuery, connection);
                    ordersAdapter.SelectCommand.Parameters.AddWithValue("@EmployeeId", employeeId);

                    DataTable ordersTable = new DataTable();
                    ordersAdapter.Fill(ordersTable);
                    dgOrders.ItemsSource = ordersTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}");
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void DgOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgOrders.SelectedItem != null)
            {
                DataRowView row = (DataRowView)dgOrders.SelectedItem;
                int orderId = Convert.ToInt32(row["ID_заказа"]);

                // Можно открыть окно с деталями заказа
                // OrderDetailsWindow detailsWindow = new OrderDetailsWindow(orderId, employeeId);
                // detailsWindow.ShowDialog();
            }
        }

        // Метод для изменения статуса заказа
        private void UpdateOrderStatus(int orderId, string newStatus)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string updateQuery = "UPDATE Заказы SET Статус = @Status WHERE ID_заказа = @OrderId";
                    SqlCommand updateCommand = new SqlCommand(updateQuery, connection);
                    updateCommand.Parameters.AddWithValue("@Status", newStatus);
                    updateCommand.Parameters.AddWithValue("@OrderId", orderId);

                    int rowsAffected = updateCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Статус заказа успешно обновлен");
                        LoadCurrentOrders(); // Обновляем список заказов
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка обновления статуса: {ex.Message}");
            }
        }

        // Пример метода для добавления новой запчасти
        private void AddNewPart(string name, string description, string article, string manufacturer, decimal price, int quantity)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string insertQuery = @"INSERT INTO Запчасти 
                                          (Наименование, Описание, Артикул, Производитель, Цена, Количество_на_складе)
                                          VALUES 
                                          (@Name, @Description, @Article, @Manufacturer, @Price, @Quantity)";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, connection);
                    insertCommand.Parameters.AddWithValue("@Name", name);
                    insertCommand.Parameters.AddWithValue("@Description", description);
                    insertCommand.Parameters.AddWithValue("@Article", article);
                    insertCommand.Parameters.AddWithValue("@Manufacturer", manufacturer);
                    insertCommand.Parameters.AddWithValue("@Price", price);
                    insertCommand.Parameters.AddWithValue("@Quantity", quantity);

                    int rowsAffected = insertCommand.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Запчасть успешно добавлена");
                        // Обновить список запчастей, если нужно
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления запчасти: {ex.Message}");
            }
        }
        }
}
