﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace Автосервис
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string connectionString = "Server=.;Database=Автосервис;Integrated Security=True;";
        public MainWindow()
        {
            InitializeComponent();
        }
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                lblError.Text = "Введите логин и пароль";
                lblError.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"SELECT Роль, ID_сотрудника, ID_клиента 
                                    FROM Учетные_данные 
                                    WHERE Логин = @Login AND Пароль = @Password";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password); // В реальном приложении используйте хэширование

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        string role = reader["Роль"].ToString();

                        if (role == "Сотрудник")
                        {
                            int employeeId = Convert.ToInt32(reader["ID_сотрудника"]);
                            EmployeeWindow employeeWindow = new EmployeeWindow(employeeId);
                            employeeWindow.Show();
                        }
                        else if (role == "Клиент")
                        {
                            int clientId = Convert.ToInt32(reader["ID_клиента"]);
                            ClientWindow clientWindow = new ClientWindow(clientId);
                            clientWindow.Show();
                        }

                        this.Hide();
                    }
                    else
                    {
                        lblError.Text = "Неверный логин или пароль";
                        lblError.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}");
            }
        }
    }
}
